# processing_code/converters/voc_converter.py
