# processing_code/preparation/voc_preparer.py
