# processing_code/preparation/coco_preparer.py
