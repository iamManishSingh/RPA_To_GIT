# processing_code/preparation/validator.py
