# fastapi_app/main.py
