import torch

def train_ssd(config):
    print("Training SSD with config:", config)
    model_path = f"{config['model_name']}_model.pt"
    torch.save({"model": "fake-ssd-weights"}, model_path)
    return {
        "mAP": 0.71,
        "precision": 0.77,
        "recall": 0.72,
        "model_artifact": model_path
    }
