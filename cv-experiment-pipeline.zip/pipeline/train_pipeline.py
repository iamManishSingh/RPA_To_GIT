import yaml
import argparse
import boto3
from models.yolov8_model import train_yolov8
from models.ssd_model import train_ssd
from utils.experiment_utils import start_experiment_run, log_metrics

def load_config(config_path):
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def upload_model_to_s3(model_path, bucket):
    s3 = boto3.client("s3")
    s3_key = f"models/{model_path}"
    s3.upload_file(model_path, bucket, s3_key)
    return f"s3://{bucket}/{s3_key}"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True, help='Path to model config YAML')
    args = parser.parse_args()

    config = load_config(args.config)
    run = start_experiment_run(config)

    if config['model_name'] == 'yolov8':
        metrics = train_yolov8(config)
    elif config['model_name'] == 'ssd':
        metrics = train_ssd(config)
    else:
        raise ValueError("Unknown model")

    if 'model_artifact' in metrics:
        model_uri = upload_model_to_s3(metrics['model_artifact'], config['s3_bucket'])
        metrics['model_uri'] = model_uri

    log_metrics(run, metrics)

if __name__ == '__main__':
    main()
