import boto3

def register_model_to_registry(model_name, model_uri, image_uri):
    sm = boto3.client('sagemaker')
    group_name = f"{model_name}-group"

    try:
        sm.create_model_package_group(
            ModelPackageGroupName=group_name,
            ModelPackageGroupDescription="Computer Vision Models"
        )
    except sm.exceptions.ResourceInUse:
        pass

    response = sm.create_model_package(
        ModelPackageGroupName=group_name,
        ModelPackageDescription=f"{model_name} candidate",
        ModelApprovalStatus="PendingManualApproval",
        InferenceSpecification={
            "Containers": [{
                "Image": image_uri,
                "ModelDataUrl": model_uri
            }],
            "SupportedContentTypes": ["application/json"],
            "SupportedResponseMIMETypes": ["application/json"]
        }
    )
    print("Model registered:", response["ModelPackageArn"])

def list_and_approve_models(model_group):
    sm = boto3.client('sagemaker')
    packages = sm.list_model_packages(ModelPackageGroupName=model_group)["ModelPackageSummaryList"]

    for pkg in packages:
        arn = pkg["ModelPackageArn"]
        status = sm.describe_model_package(ModelPackageName=arn)["ModelApprovalStatus"]
        print(f"{arn} --> {status}")
        if status != "Approved":
            sm.update_model_package(
                ModelPackageArn=arn,
                ModelApprovalStatus="Approved"
            )
            print(f"Approved: {arn}")
