import os
import boto3
from sklearn.model_selection import train_test_split

def download_data_from_s3(bucket_name, local_dir):
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    for obj in bucket.objects.all():
        path = os.path.join(local_dir, obj.key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        bucket.download_file(obj.key, path)

def split_dataset(image_dir, output_dir):
    images = os.listdir(image_dir)
    train_imgs, test_imgs = train_test_split(images, test_size=0.2, random_state=42)
    with open(os.path.join(output_dir, 'train.txt'), 'w') as f:
        f.writelines("\n".join(train_imgs))
    with open(os.path.join(output_dir, 'val.txt'), 'w') as f:
        f.writelines("\n".join(test_imgs))
