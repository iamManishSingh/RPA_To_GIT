import sagemaker
from sagemaker.experiments.run import Run

def start_experiment_run(config):
    sm_session = sagemaker.Session()
    with Run(experiment_name=config['experiment_name'], run_name=config['trial_name'], sagemaker_session=sm_session) as run:
        for key, value in config.items():
            run.log_parameter(key, value)
        return run

def log_metrics(run, metrics):
    for key, value in metrics.items():
        run.log_metric(key, value)
