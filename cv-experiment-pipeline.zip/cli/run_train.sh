#!/bin/bash
CONFIG_PATH=$1
if [ -z "$CONFIG_PATH" ]; then
  echo "Usage: ./run_train.sh <config.yaml>"
  exit 1
fi
python3 pipeline/train_pipeline.py --config $CONFIG_PATH
