#!/bin/bash
MODEL_NAME=$1
MODEL_URI=$2
IMAGE_URI=$3
if [ -z "$MODEL_NAME" ] || [ -z "$MODEL_URI" ] || [ -z "$IMAGE_URI" ]; then
  echo "Usage: ./run_register.sh <model_name> <s3_model_uri> <image_uri>"
  exit 1
fi
python3 -c "
from pipeline.registry import register_model_to_registry
register_model_to_registry('$MODEL_NAME', '$MODEL_URI', '$IMAGE_URI')
"
