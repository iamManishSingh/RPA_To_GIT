# SageMaker Manifest Converter API

Run using:
```bash
uvicorn app.main:app --reload
```