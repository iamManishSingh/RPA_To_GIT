from pydantic import BaseModel
from enum import Enum

class UseCaseType(str, Enum):
    object_detection = "object_detection"

class OutputFormat(str, Enum):
    coco = "coco"
    voc = "voc"
    yolo = "yolo"
    csv = "csv"

class ConvertRequest(BaseModel):
    use_case_type: UseCaseType
    output_format: OutputFormat
    manifest_s3_path: str
    output_s3_path: str = None