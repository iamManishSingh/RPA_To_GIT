from fastapi import FastAPI, HTTPException
from app.schemas import ConvertRequest
from app.converter import convert_manifest

app = FastAPI(title="SageMaker Manifest Format Converter")

@app.post("/convert")
def convert(request: ConvertRequest):
    try:
        result_path = convert_manifest(
            request.use_case_type,
            request.output_format,
            request.manifest_s3_path,
            request.output_s3_path
        )
        return {"status": "success", "message": f"Converted to {request.output_format}", "path": result_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))