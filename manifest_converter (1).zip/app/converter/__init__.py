from .coco_converter import convert_to_coco
from .voc_converter import convert_to_voc
from .yolo_converter import convert_to_yolo
from .csv_converter import convert_to_csv
from .utils import parse_manifest

def convert_manifest(use_case_type, output_format, manifest_path, output_path=None):
    data = parse_manifest(manifest_path)

    if output_format == "coco":
        return convert_to_coco(data, output_path)
    elif output_format == "voc":
        return convert_to_voc(data, output_path)
    elif output_format == "yolo":
        return convert_to_yolo(data, output_path)
    elif output_format == "csv":
        return convert_to_csv(data, output_path)
    else:
        raise ValueError("Unsupported format.")