import os
import csv

def convert_to_csv(data, output_path=None):
    csv_path = output_path or "./output/annotations.csv"
    os.makedirs(os.path.dirname(csv_path), exist_ok=True)
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["image_name", "label", "xmin", "ymin", "xmax", "ymax"])
        for item in data:
            file_name = item["source-ref"].split("/")[-1]
            class_map = item["bounding-box-metadata"]["class-map"]
            for ann in item["bounding-box"]["annotations"]:
                label = class_map[str(ann["class_id"])]
                xmin = ann["left"]
                ymin = ann["top"]
                xmax = xmin + ann["width"]
                ymax = ymin + ann["height"]
                writer.writerow([file_name, label, xmin, ymin, xmax, ymax])
    return csv_path