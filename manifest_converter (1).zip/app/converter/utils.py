import json

def parse_manifest(manifest_file):
    data = []
    with open(manifest_file, 'r') as f:
        for line in f:
            data.append(json.loads(line.strip()))
    return data