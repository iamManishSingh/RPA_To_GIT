import os

def convert_to_yolo(data, output_path=None):
    output_dir = output_path or "./output/yolo/"
    os.makedirs(output_dir, exist_ok=True)

    for item in data:
        file_name = item["source-ref"].split("/")[-1]
        size = item["bounding-box"]["image_size"][0]
        annotations = item["bounding-box"]["annotations"]

        label_path = os.path.join(output_dir, file_name.replace(".jpg", ".txt"))
        with open(label_path, "w") as f:
            for ann in annotations:
                class_id = ann["class_id"]
                x_center = (ann["left"] + ann["width"] / 2) / size["width"]
                y_center = (ann["top"] + ann["height"] / 2) / size["height"]
                width = ann["width"] / size["width"]
                height = ann["height"] / size["height"]
                f.write(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}\n")
    return output_dir