import os
import xml.etree.ElementTree as ET

def convert_to_voc(data, output_path=None):
    output_dir = output_path or "./output/voc/"
    os.makedirs(output_dir, exist_ok=True)

    for item in data:
        file_name = item["source-ref"].split("/")[-1]
        size = item["bounding-box"]["image_size"][0]
        annotations = item["bounding-box"]["annotations"]
        class_map = item["bounding-box-metadata"]["class-map"]

        annotation = ET.Element("annotation")
        ET.SubElement(annotation, "filename").text = file_name
        size_elem = ET.SubElement(annotation, "size")
        ET.SubElement(size_elem, "width").text = str(size["width"])
        ET.SubElement(size_elem, "height").text = str(size["height"])
        ET.SubElement(size_elem, "depth").text = str(size["depth"])

        for ann in annotations:
            obj = ET.SubElement(annotation, "object")
            ET.SubElement(obj, "name").text = class_map[str(ann["class_id"])]
            bbox = ET.SubElement(obj, "bndbox")
            ET.SubElement(bbox, "xmin").text = str(ann["left"])
            ET.SubElement(bbox, "ymin").text = str(ann["top"])
            ET.SubElement(bbox, "xmax").text = str(ann["left"] + ann["width"])
            ET.SubElement(bbox, "ymax").text = str(ann["top"] + ann["height"])

        tree = ET.ElementTree(annotation)
        tree.write(os.path.join(output_dir, file_name.replace(".jpg", ".xml")))
    return output_dir