import json, os

def convert_to_coco(data, output_path=None):
    images, annotations, categories = [], [], []
    category_map = {}
    annotation_id = 1

    for idx, item in enumerate(data):
        file_name = item["source-ref"].split("/")[-1]
        size = item["bounding-box"]["image_size"][0]
        image_id = idx + 1

        images.append({"id": image_id, "file_name": file_name, "width": size["width"], "height": size["height"]})
        class_map = item["bounding-box-metadata"]["class-map"]

        for ann in item["bounding-box"]["annotations"]:
            label = class_map[str(ann["class_id"])]
            if label not in category_map:
                category_map[label] = len(category_map) + 1
                categories.append({"id": category_map[label], "name": label})
            annotations.append({
                "id": annotation_id,
                "image_id": image_id,
                "category_id": category_map[label],
                "bbox": [ann["left"], ann["top"], ann["width"], ann["height"]],
                "area": ann["width"] * ann["height"],
                "iscrowd": 0
            })
            annotation_id += 1

    coco_dict = {"images": images, "annotations": annotations, "categories": categories}
    out_path = output_path or "./output/coco.json"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(coco_dict, f, indent=2)
    return out_path