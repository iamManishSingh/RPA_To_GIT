import streamlit as st

class InputPanel:
    def show(self):
        with st.expander("⚙️ Input Settings", expanded=True):
            input_method = st.radio(
                "Input Method",
                ["SMILES", "Image Upload"],
                horizontal=True
            )
            
            input_data = {
                "input_method": input_method,
                "conversion_backend": None,
                "reference_smiles": "",
                "target_smiles": "",
                "reference_image": None,
                "target_images": [],
                "fingerprint_type": "Morgan",
                "similarity_metric": "Tanimoto"
            }
            
            if input_method == "SMILES":
                input_data["reference_smiles"] = st.text_area(
                    "Reference Molecule (SMILES)",
                    value="C1CCCCC1",
                    placeholder="Enter SMILES string"
                )
                
                input_data["target_smiles"] = st.text_area(
                    "Target Molecules (one per line)",
                    value="C1CCCCC1\nC1CCNCC1",
                    placeholder="Enter multiple SMILES strings"
                )
            else:
                input_data["reference_image"] = st.file_uploader(
                    "Reference Molecule Image",
                    type=["png", "jpg", "jpeg"]
                )
                
                input_data["target_images"] = st.file_uploader(
                    "Target Molecule Images",
                    type=["png", "jpg", "jpeg"],
                    accept_multiple_files=True
                )
                
                # Only show DECIMER and RDKit options
                input_data["conversion_backend"] = st.radio(
                    "Conversion Backend",
                    ["DECIMER (AI-powered)", "RDKit"],
                    horizontal=True,
                    help="DECIMER: Best for published structures\n"
                         "RDKit: Basic fallback option"
                )
            
            with st.expander("🔍 Analysis Settings"):
                input_data["fingerprint_type"] = st.selectbox(
                    "Fingerprint Type",
                    ["Morgan", "RDKit", "MACCS", "Atom_Pair"],
                    index=0
                )
                
                input_data["similarity_metric"] = st.selectbox(
                    "Similarity Metric",
                    ["Tanimoto", "Dice", "Cosine"],
                    index=0
                )
            
            return input_data