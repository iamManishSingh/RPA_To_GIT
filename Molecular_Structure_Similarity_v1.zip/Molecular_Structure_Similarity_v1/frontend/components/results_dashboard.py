import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from PIL import Image
import io

class ResultsDashboard:
    def show(self, results):
        st.header("Results")
        
        # Prepare data for display
        display_data = {
            "Molecule": results["target_smiles"],
            "Similarity": results["similarities"],
            "Structure": results["mol_images"][1:]  # Skip reference
        }
        
        # Create tabs
        tab1, tab2, tab3 = st.tabs(["📊 Data Table", "📈 Heatmap", "🔬 Molecule Viewer"])
        
        with tab1:
            st.subheader("Similarity Scores")
            df = pd.DataFrame({
                "Molecule": results["target_smiles"],
                "Similarity": results["similarities"],
            })
            
            st.dataframe(
                df.style.format({"Similarity": "{:.3f}"}),
                column_config={
                    "Similarity": st.column_config.ProgressColumn(
                        format="%.3f",
                        min_value=0,
                        max_value=1
                    )
                },
                hide_index=True,
                use_container_width=True
            )
        
        with tab2:
            st.subheader("Similarity Heatmap")
            fig, ax = plt.subplots()
            sns.heatmap(
                pd.DataFrame({
                    "Molecule": results["target_smiles"],
                    "Similarity": results["similarities"]
                }).set_index("Molecule"),
                annot=True,
                cmap="YlGnBu",
                vmin=0,
                vmax=1,
                ax=ax
            )
            st.pyplot(fig)
        
        with tab3:
            st.subheader("Molecule Inspection")
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Reference Molecule**")
                st.image(results["mol_images"][0], use_container_width=True)
                st.code(results["reference_smiles"])
            
            with col2:
                selected_idx = st.selectbox(
                    "Select target molecule",
                    range(len(results["target_smiles"])),
                    format_func=lambda x: results["target_smiles"][x]
                )
                
                st.image(results["mol_images"][selected_idx+1], use_container_width=True)
                st.code(results["target_smiles"][selected_idx])
                
                similarity = results["similarities"][selected_idx]
                st.metric(
                    "Similarity Score",
                    value=f"{similarity:.3f}",
                    delta="High similarity" if similarity > 0.7 
                          else "Moderate similarity" if similarity > 0.4 
                          else "Low similarity"
                )
                
                st.caption(f"Fingerprint: {results['fingerprint_type']}")
                st.caption(f"Metric: {results['similarity_metric']}")