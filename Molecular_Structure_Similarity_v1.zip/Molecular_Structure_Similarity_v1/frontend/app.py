import streamlit as st
from components.input_panel import InputPanel
from components.results_dashboard import ResultsDashboard
import requests
from PIL import Image
import io
import time

# Page config
st.set_page_config(
    page_title="Molecular Similarity Analyzer",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'run_analysis' not in st.session_state:
    st.session_state.run_analysis = False
if 'results' not in st.session_state:
    st.session_state.results = None

# Main title
st.title("🧪 Molecular Similarity Analyzer")
st.markdown("Compare molecular structures using fingerprint-based methods")

# Initialize components
input_panel = InputPanel()
results_dashboard = ResultsDashboard()

# Main columns
col1, col2 = st.columns([1, 2])

with col1:
    # Get user input
    input_data = input_panel.show()

    if st.button("🚀 Run Analysis", type="primary", use_container_width=True):
        st.session_state.run_analysis = True
        st.session_state.results = None
        
        with st.spinner("Calculating similarities..."):
            try:
                # Process based on input method
                if input_data["input_method"] == "SMILES":
                    reference = input_data["reference_smiles"]
                    targets = input_data["target_smiles"].split("\n")
                else:
                    # Convert images to SMILES
                    backend_map = {
                        "DECIMER (AI-powered)": "decimer",
                        "OpenBabel": "openbabel",
                        "RDKit": "rdkit"
                    }
                    
                    # Convert reference
                    ref_response = requests.post(
                        "http://localhost:8000/api/convert/image-to-smiles",
                        files={"file": input_data["reference_image"]},
                        params={"backend": backend_map[input_data["conversion_backend"]]}
                    ).json()
                    reference = ref_response["smiles"]
                    
                    # Convert targets
                    targets = []
                    for img in input_data["target_images"]:
                        target_response = requests.post(
                            "http://localhost:8000/api/convert/image-to-smiles",
                            files={"file": img},
                            params={"backend": backend_map[input_data["conversion_backend"]]}
                        ).json()
                        targets.append(target_response["smiles"])
                
                # Calculate similarities
                similarity_response = requests.post(
                    "http://localhost:8000/api/calculate/similarity",
                    json={
                        "reference_smiles": reference,
                        "target_smiles": targets,
                        "fingerprint_type": input_data["fingerprint_type"].lower(),
                        "similarity_metric": input_data["similarity_metric"].lower()
                    }
                ).json()
                
                # Generate molecule images
                from rdkit import Chem
                from rdkit.Chem import Draw
                
                mol_images = []
                all_smiles = [reference] + targets
                for smiles in all_smiles:
                    mol = Chem.MolFromSmiles(smiles)
                    img = Draw.MolToImage(mol, size=(300, 300))
                    buf = io.BytesIO()
                    img.save(buf, format="PNG")
                    mol_images.append(buf.getvalue())
                
                # Prepare results
                st.session_state.results = {
                    "reference_smiles": reference,
                    "target_smiles": targets,
                    "similarities": similarity_response["similarities"],
                    "fingerprint_type": input_data["fingerprint_type"],
                    "similarity_metric": input_data["similarity_metric"],
                    "mol_images": mol_images
                }
                
            except Exception as e:
                st.error(f"Analysis failed: {str(e)}")
                st.session_state.run_analysis = False

with col2:
    if st.session_state.run_analysis:
        if st.session_state.results:
            results_dashboard.show(st.session_state.results)
        else:
            st.warning("Analysis in progress...")
            time.sleep(1)
            st.rerun()