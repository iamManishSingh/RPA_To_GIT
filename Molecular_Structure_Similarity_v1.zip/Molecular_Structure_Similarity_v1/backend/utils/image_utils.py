from PIL import Image, ImageOps
import io
import numpy as np
from typing import Optional

def preprocess_image(image_bytes: bytes) -> Optional[Image.Image]:
    """Preprocess chemical structure images for conversion"""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        
        # Convert to grayscale if needed
        if img.mode != 'L':
            img = ImageOps.grayscale(img)
            
        # Enhance contrast
        img = ImageOps.autocontrast(img)
        
        return img
    except Exception as e:
        raise ValueError(f"Image preprocessing failed: {str(e)}")

def image_to_bytes(image: Image.Image, format: str = 'PNG') -> bytes:
    """Convert PIL Image to bytes"""
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format=format)
    return img_byte_arr.getvalue()

def draw_molecule_grid(smiles_list: list, mols_per_row: int = 4, size: tuple = (200, 200)) -> Optional[Image.Image]:
    """Generate a grid of molecule images"""
    from rdkit import Chem
    from rdkit.Chem import Draw
    
    mols = [Chem.MolFromSmiles(s) for s in smiles_list if Chem.MolFromSmiles(s)]
    if not mols:
        return None
        
    return Draw.MolsToGridImage(
        mols,
        molsPerRow=mols_per_row,
        subImgSize=size
    )