from fastapi import FastAPI, UploadFile, File, HTTPException
from rdkit import DataStructs
from typing import List
import numpy as np
from fastapi.middleware.cors import CORSMiddleware
from services import (
    conversion_service, 
    fingerprint_service, 
    similarity_service
)
from schemas.request_models import SimilarityRequest
from schemas.response_models import SimilarityResponse
import logging

app = FastAPI(title="Molecular Similarity API")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/convert/image-to-smiles")
async def convert_image_to_smiles(
    file: UploadFile = File(...),
    backend: str = "decimer"
):
    """Convert chemical structure image to SMILES string"""
    valid_backends = ["decimer", "rdkit"]
    if backend not in valid_backends:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid backend. Choose from {valid_backends}"
        )
    
    try:
        image_bytes = await file.read()
        smiles = conversion_service.image_to_smiles(image_bytes, backend)
        if not smiles:
            raise HTTPException(400, detail="Conversion returned empty SMILES")
        return {"smiles": smiles, "backend_used": backend}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Image conversion failed: {str(e)}")
        raise HTTPException(500, detail="Image conversion service error")


@app.post("/api/calculate/similarity")
async def calculate_similarity(request: SimilarityRequest):
    try:
        # Validate fingerprint type
        fp_type = request.fingerprint_type.lower()
        valid_types = ["morgan", "maccs", "atom_pair", "rdkit"]
        if fp_type not in valid_types:
            raise HTTPException(400, detail=f"Invalid type. Use: {valid_types}")

        # Generate reference fingerprint
        try:
            ref_fp = fingerprint_service.generate_fingerprint(
                request.reference_smiles,
                fp_type
            )
            if ref_fp is None:
                raise HTTPException(400, detail="Invalid reference SMILES")
        except ValueError as e:
            raise HTTPException(400, detail=str(e))

        # Process targets
        results = []
        invalid = []
        for i, smi in enumerate(request.target_smiles):
            try:
                fp = fingerprint_service.generate_fingerprint(smi, fp_type)
                if fp is None:
                    invalid.append(i)
                    results.append(None)
                    continue
                    
                # Use the proper similarity service
                similarity = similarity_service.calculate_similarity(
                    ref_fp, 
                    [fp],  # Wrap in list for consistency
                    request.similarity_metric
                )[0]  # Unwrap single result
                
                results.append(float(similarity))
            except Exception:
                invalid.append(i)
                results.append(None)

        if all(r is None for r in results):
            raise HTTPException(400, detail="No valid targets processed")

        return {
            "reference": request.reference_smiles,
            "targets": request.target_smiles,
            "similarities": results,
            "invalid_indices": invalid,
            "fingerprint_type": fp_type,
            "metric": request.similarity_metric
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, detail=f"Server error: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
    