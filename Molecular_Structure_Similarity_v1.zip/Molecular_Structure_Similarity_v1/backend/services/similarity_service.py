from rdkit import DataStructs
from typing import List
import numpy as np

class SimilarityService:
    @staticmethod
    def _debug_metrics(ref_fp, target_fp):
        """Debug metrics that match actual calculations"""
        # Get consistent array representations
        ref_arr = np.array([int(b) for b in ref_fp.ToBitString()], dtype=int)
        target_arr = np.array([int(b) for b in target_fp.ToBitString()], dtype=int)
        
        # Calculate all metrics consistently
        intersection = np.sum(ref_arr & target_arr)
        union = np.sum(ref_arr | target_arr)
        ref_count = np.sum(ref_arr)
        target_count = np.sum(target_arr)
        
        # Actual metrics used in calculations
        tanimoto = intersection / union if union > 0 else 0
        dice = (2 * intersection) / (ref_count + target_count) if (ref_count + target_count) > 0 else 0
        cosine = intersection / (np.sqrt(ref_count) * np.sqrt(target_count)) if (ref_count * target_count) > 0 else 0
        
        print("\n=== Metric Debug ===")
        print(f"Tanimoto (intersection/union):       {intersection}/{union} = {tanimoto:.4f}")
        print(f"Dice (2*intersection/(a+b)):         {2*intersection}/{ref_count + target_count} = {dice:.4f}")
        print(f"Cosine (intersection/sqrt(a*b)):     {intersection}/sqrt({ref_count}*{target_count}) = {cosine:.4f}")
        print(f"\nBits set in reference:  {ref_count}")
        print(f"Bits set in target:    {target_count}")
        print(f"Common bits set:       {intersection}")

    @staticmethod
    def calculate_similarity(
        ref_fp,
        target_fps: List,
        metric: str = "tanimoto"
    ) -> List[float]:
        """Enhanced similarity calculation with validation"""
        # Validate inputs
        if ref_fp is None:
            raise ValueError("Reference fingerprint cannot be None")
        if not target_fps:
            raise ValueError("Target fingerprints list cannot be empty")
        if any(fp is None for fp in target_fps):
            raise ValueError("None values in target fingerprints")

        metric = metric.lower()
        
        # Debug first target
        if len(target_fps) > 0:
            SimilarityService._debug_metrics(ref_fp, target_fps[0])
        
        try:
            if metric == "tanimoto":
                return [float(DataStructs.TanimotoSimilarity(ref_fp, fp)) for fp in target_fps]
            
            elif metric == "dice":
                return [float(DataStructs.DiceSimilarity(ref_fp, fp)) for fp in target_fps]
            
            elif metric == "cosine":
                return SimilarityService._cosine_similarity(ref_fp, target_fps)
            
            raise ValueError(f"Unsupported metric: {metric}. Use tanimoto/dice/cosine")
            
        except Exception as e:
            raise ValueError(f"Similarity calculation failed: {str(e)}")

    @staticmethod
    def _cosine_similarity(ref_fp, target_fps):
        """Consistent cosine similarity calculation"""
        # Get reference array once
        ref_arr = np.array([int(b) for b in ref_fp.ToBitString()], dtype=float)
        ref_norm = np.linalg.norm(ref_arr)
        
        results = []
        for fp in target_fps:
            target_arr = np.array([int(b) for b in fp.ToBitString()], dtype=float)
            target_norm = np.linalg.norm(target_arr)
            
            if ref_norm == 0 or target_norm == 0:
                results.append(0.0)
                continue
                
            dot = np.dot(ref_arr, target_arr)
            cosine = dot / (ref_norm * target_norm)
            results.append(float(cosine))
            
        return results

similarity_service = SimilarityService()