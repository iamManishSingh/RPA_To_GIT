from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem, MACCSkeys
from rdkit.Chem.AtomPairs import Pairs
from typing import Optional

class FingerprintService:
    @staticmethod
    def generate_fingerprint(
        smiles: str,
        fp_type: str = "morgan"
    ) -> Optional[DataStructs.ExplicitBitVect]:
        """Generate molecular fingerprint with universal compatibility"""
        try:
            mol = Chem.MolFromSmiles(smiles)
            if not mol:
                return None

            fp_type = fp_type.lower()
            
            if fp_type == "morgan":
                return AllChem.GetMorganFingerprintAsBitVect(mol, 2)
            
            elif fp_type == "maccs":
                fp = MACCSkeys.GenMACCSKeys(mol)
                # Universal MACCS handling
                if isinstance(fp, DataStructs.ExplicitBitVect):
                    return fp
                # For older RDKit versions
                ebv = DataStructs.ExplicitBitVect(167)
                if hasattr(fp, 'ToBitString'):
                    ebv.FromBase64(fp.ToBase64())  # More reliable than ToBitString
                return ebv
            
            elif fp_type == "atom_pair":
                return Pairs.GetAtomPairFingerprintAsBitVect(mol)
            
            elif fp_type == "rdkit":
                return Chem.RDKFingerprint(mol)
            
            raise ValueError(f"Unsupported fingerprint type: {fp_type}")
            
        except Exception as e:
            raise ValueError(f"Fingerprint generation failed: {str(e)}")

fingerprint_service = FingerprintService()