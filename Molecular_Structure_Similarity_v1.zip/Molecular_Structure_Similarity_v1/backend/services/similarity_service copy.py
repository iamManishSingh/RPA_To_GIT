from rdkit import DataStructs
from typing import List
import numpy as np

class SimilarityService:
    @staticmethod
    def calculate_similarity(
        ref_fp,
        target_fps: List,
        metric: str = "tanimoto"
    ) -> List[float]:
        """Universal similarity calculation"""
        if not ref_fp or not target_fps:
            raise ValueError("Invalid fingerprints provided")

        metric = metric.lower()
        try:
            if metric == "tanimoto":
                return [float(DataStructs.TanimotoSimilarity(ref_fp, fp)) for fp in target_fps]
            
            elif metric == "dice":
                return [float(DataStructs.DiceSimilarity(ref_fp, fp)) for fp in target_fps]
            
            elif metric == "cosine":
                return SimilarityService._cosine_similarity(ref_fp, target_fps)
            
            raise ValueError(f"Unsupported metric: {metric}")
            
        except Exception as e:
            raise ValueError(f"Similarity calculation failed: {str(e)}")

    @staticmethod
    def _cosine_similarity(ref_fp, target_fps):
        """Universal cosine similarity"""
        try:
            # Convert fingerprints to numpy arrays
            def fp_to_array(fp):
                if hasattr(fp, 'GetNumBits'):
                    return np.array([int(b) for b in fp.ToBitString()], dtype=float)
                return np.array(fp, dtype=float)
            
            ref_arr = fp_to_array(ref_fp)
            results = []
            for fp in target_fps:
                target_arr = fp_to_array(fp)
                dot = np.dot(ref_arr, target_arr)
                norm = np.linalg.norm(ref_arr) * np.linalg.norm(target_arr)
                results.append(float(dot/norm) if norm != 0 else 0.0)
            return results
        except Exception:
            raise ValueError("Cosine similarity requires bit vector fingerprints")

similarity_service = SimilarityService()