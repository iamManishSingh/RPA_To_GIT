from pydantic import BaseModel, Field
from typing import List

class SimilarityRequest(BaseModel):
    reference_smiles: str = Field(..., example="C1CCCCC1")
    target_smiles: List[str] = Field(..., example=["C1CCCCC1", "C1CCNCC1"])
    fingerprint_type: str = Field("morgan", example="morgan")
    similarity_metric: str = Field("tanimoto", example="tanimoto")