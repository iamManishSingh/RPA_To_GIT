from pydantic import BaseModel
from typing import List

class SimilarityResponse(BaseModel):
    reference_smiles: str
    target_smiles: List[str]
    similarities: List[float]
    fingerprint_type: str
    similarity_metric: str