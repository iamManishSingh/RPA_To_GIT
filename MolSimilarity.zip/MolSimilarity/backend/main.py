from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import conversion, similarity, molecules
from models.responses import FingerprintMethodsResponse
from services.fingerprints import get_available_methods

app = FastAPI(title="Molecular Similarity API")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(conversion.router)
app.include_router(similarity.router)
app.include_router(molecules.router)

@app.get("/methods", response_model=FingerprintMethodsResponse)
async def get_fingerprint_methods():
    """Endpoint to list available fingerprint methods"""
    return {
        "available_methods": get_available_methods(),
        "default_methods": ["morgan", "atom_pair"]
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy"}