from pydantic import BaseModel
from typing import Optional, Dict, List

class MoleculeImageResponse(BaseModel):
    success: bool
    image: Optional[str]
    error: Optional[str]

class FingerprintMethodsResponse(BaseModel):
    available_methods: Dict[str, str]
    default_methods: List[str]

class BatchSimilarityResponse(BaseModel):
    master_smiles: str
    results: Dict[str, Dict[str, float]]
    metrics: Dict[str, str]
    timing: Dict[str, float]