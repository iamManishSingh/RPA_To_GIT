from pydantic import BaseModel
from typing import List, Dict, Optional

class ConversionResponse(BaseModel):
    success: bool
    smiles: Optional[str]
    error: Optional[str]

class SimilarityRequest(BaseModel):
    master_smiles: str
    target_smiles: List[str]
    methods: List[str]
    metric: str = "tanimoto"

class SimilarityResponse(BaseModel):
    master: str
    results: Dict[str, Dict[str, Optional[float]]]
    methods: List[str]
    metric: str