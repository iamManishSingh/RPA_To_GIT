from rdkit import DataStructs
from typing import Union

def calculate_similarity(fp1, fp2, metric: str = "tanimoto") -> Union[float, None]:
    """Calculate similarity between two fingerprints"""
    if not fp1 or not fp2:
        return None
        
    try:
        if metric == "tanimoto":
            return DataStructs.TanimotoSimilarity(fp1, fp2)
        elif metric == "dice":
            return DataStructs.DiceSimilarity(fp1, fp2)
    except Exception as e:
        print(f"Similarity calculation error: {e}")
    return None