from rdkit import Chem
from decimer import DECIMER
from io import BytesIO
from PIL import Image

def image_to_smiles(image_bytes: bytes) -> str:
    """Convert molecular image to SMILES using DECIMER"""
    try:
        # Convert bytes to PIL Image
        img = Image.open(BytesIO(image_bytes))
        # Convert to PNG if not already
        if img.format != 'PNG':
            png_buffer = BytesIO()
            img.save(png_buffer, format='PNG')
            image_bytes = png_buffer.getvalue()
        
        smiles = DECIMER(image_bytes=image_bytes)
        # Validate the SMILES
        mol = Chem.MolFromSmiles(smiles)
        if mol:
            return Chem.MolToSmiles(mol)
        return None
    except Exception as e:
        print(f"Conversion error: {e}")
        return None