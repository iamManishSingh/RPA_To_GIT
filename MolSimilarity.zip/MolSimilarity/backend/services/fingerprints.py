from rdkit import Chem
from rdkit.Chem import AllChem
from typing import Dict, Optional

FINGERPRINT_METHODS = {
    "morgan": "Morgan Fingerprint (radius=2)",
    "rdkit": "RDKit Fingerprint",
    "maccs": "MACCS Keys",
    "atom_pair": "Atom Pair",
    "topological": "Topological Torsion"
}

def get_available_methods() -> Dict[str, str]:
    return FINGERPRINT_METHODS

def generate_fingerprint(smiles: str, method: str):
    """Generate fingerprint for given SMILES using specified method"""
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        return None

    try:
        if method == "morgan":
            return AllChem.GetMorganFingerprintAsBitVect(mol, radius=2)
        elif method == "rdkit":
            return Chem.RDKFingerprint(mol)
        elif method == "maccs":
            return AllChem.GetMACCSKeysFingerprint(mol)
        elif method == "atom_pair":
            return AllChem.GetAtomPairFingerprintAsBitVect(mol)
        elif method == "topological":
            return AllChem.GetTopologicalTorsionFingerprintAsBitVect(mol)
    except Exception as e:
        print(f"Fingerprint generation error ({method}): {e}")
    return None