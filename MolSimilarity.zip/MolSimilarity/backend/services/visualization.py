from rdkit import Chem
from rdkit.Chem import Draw
from io import BytesIO
import base64

def smiles_to_image(smiles: str, width: int = 300, height: int = 300) -> str:
    """Convert SMILES to base64-encoded PNG image"""
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        return None
    
    img = Draw.MolToImage(mol, size=(width, height))
    with BytesIO() as buffer:
        img.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode()