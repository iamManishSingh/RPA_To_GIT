from fastapi import APIRouter, UploadFile, File
from services.conversion import image_to_smiles
from models.schemas import ConversionResponse
from io import BytesIO

router = APIRouter(prefix="/conversion", tags=["Conversion"])

@router.post("/image-to-smiles", response_model=ConversionResponse)
async def convert_image_to_smiles(file: UploadFile = File(...)):
    image_bytes = await file.read()
    smiles = image_to_smiles(image_bytes)
    return {
        "success": smiles is not None,
        "smiles": smiles,
        "error": None if smiles else "Failed to convert image to valid SMILES"
    }