from fastapi import APIRouter
from models.schemas import SimilarityRequest, SimilarityResponse
from services.fingerprints import generate_fingerprint
from services.similarity import calculate_similarity

router = APIRouter(prefix="/similarity", tags=["Similarity"])

@router.post("/compare", response_model=SimilarityResponse)
async def compare_molecules(request: SimilarityRequest):
    results = {}
    master_fps = {}
    
    # Generate fingerprints for master molecule
    for method in request.methods:
        master_fps[method] = generate_fingerprint(request.master_smiles, method)
    
    # Compare with each target
    for target in request.target_smiles:
        results[target] = {}
        for method in request.methods:
            target_fp = generate_fingerprint(target, method)
            similarity = calculate_similarity(
                master_fps[method],
                target_fp,
                request.metric
            ) if (master_fps[method] and target_fp) else None
            results[target][method] = similarity
    
    return {
        "master": request.master_smiles,
        "results": results,
        "methods": request.methods,
        "metric": request.metric
    }