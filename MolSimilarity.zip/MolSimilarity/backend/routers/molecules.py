from fastapi import APIRouter, HTTPException
from rdkit import Chem
from rdkit.Chem import Draw
from io import BytesIO
import base64

router = APIRouter(prefix="/molecules", tags=["Molecules"])

@router.get("/{smiles}/image")
async def get_molecule_image(smiles: str, width: int = 300, height: int = 300):
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        raise HTTPException(status_code=400, detail="Invalid SMILES string")
    
    img = Draw.MolToImage(mol, size=(width, height))
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    img_str = base64.b64encode(buffer.getvalue()).decode()
    
    return {"image": f"data:image/png;base64,{img_str}"}