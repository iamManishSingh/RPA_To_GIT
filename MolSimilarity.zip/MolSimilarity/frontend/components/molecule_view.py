import streamlit as st
from utils.api_client import get_molecule_image

def display_molecule_details(smiles: str, properties: dict):
    """Display detailed molecular view with structure and properties"""
    if not smiles:
        return
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader("Molecular Structure")
        img = get_molecule_image(smiles)
        if img:
            st.image(img, use_column_width=True)
        else:
            st.warning("Could not render structure")
    
    with col2:
        st.subheader("Properties")
        if properties:
            for prop, value in properties.items():
                st.metric(label=prop, value=value)
        else:
            st.info("No additional properties available")
        
        st.code(f"SMILES: {smiles}", language="text")