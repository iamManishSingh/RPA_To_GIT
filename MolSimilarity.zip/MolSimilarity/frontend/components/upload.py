import streamlit as st
from typing import Tuple, List, Union
from io import BytesIO

def file_uploader() -> Tuple[Union[BytesIO, str], List[Union[BytesIO, str]]]:
    """Component for uploading master and target molecules"""
    input_type = st.radio(
        "Input type:",
        ["Image", "SMILES"],
        help="Choose between image files or SMILES strings"
    )
    
    if input_type == "Image":
        master = st.file_uploader(
            "Upload Master Molecule (Image)",
            type=["png", "jpg", "jpeg"],
            key="master"
        )
        targets = st.file_uploader(
            "Upload Target Molecules (Images)",
            type=["png", "jpg", "jpeg"],
            accept_multiple_files=True,
            key="targets"
        )
    else:
        master = st.text_area(
            "Enter Master Molecule (SMILES)",
            placeholder="E.g. CCO for ethanol",
            key="master_smiles"
        )
        targets = st.text_area(
            "Enter Target Molecules (SMILES, one per line)",
            placeholder="One SMILES per line\nCCO\nCC(=O)O",
            key="target_smiles"
        ).split('\n') if st.session_state.get('target_smiles') else []
    
    return master, targets

def fingerprint_selector() -> List[str]:
    """Component for selecting fingerprint methods"""
    methods = {
        "morgan": "Morgan Fingerprint",
        "rdkit": "RDKit Fingerprint",
        "maccs": "MACCS Keys",
        "atom_pair": "Atom Pair",
        "topological": "Topological Torsion"
    }
    selected = st.multiselect(
        "Select Fingerprint Methods:",
        options=list(methods.keys()),
        format_func=lambda x: methods[x],
        default=["morgan", "atom_pair"]
    )
    return selected