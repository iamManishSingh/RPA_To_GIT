import streamlit as st
import pandas as pd
import plotly.express as px
from utils.api_client import get_molecule_image

def display_results(results):
    if not results:
        st.error("No results to display")
        return
    
    # Prepare data
    df = pd.DataFrame(results['results']).T
    methods = results['methods']
    
    st.header("Similarity Results")
    
    # Heatmap
    st.subheader("Similarity Heatmap")
    fig = px.imshow(
        df,
        labels=dict(x="Methods", y="Target Molecules", color="Similarity"),
        color_continuous_scale="viridis",
        aspect="auto"
    )
    st.plotly_chart(fig, use_container_width=True)
    
    # Detailed view
    st.subheader("Detailed Comparison")
    selected_target = st.selectbox(
        "Select target molecule to view details:",
        options=list(results['results'].keys())
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Molecular Structures**")
        st.image(get_molecule_image(results['master']), caption="Master Molecule")
        st.image(get_molecule_image(selected_target), caption="Target Molecule")
    
    with col2:
        st.markdown("**Similarity Scores**")
        target_results = results['results'][selected_target]
        method_df = pd.DataFrame({
            "Method": methods,
            "Score": [target_results[m] for m in methods]
        })
        st.dataframe(method_df.style.highlight_max(axis=0))
        
        fig = px.bar(
            method_df,
            x="Method",
            y="Score",
            title="Similarity by Method"
        )
        st.plotly_chart(fig, use_container_width=True)