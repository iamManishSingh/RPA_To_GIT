import streamlit as st
from components.upload import file_uploader, fingerprint_selector
from components.visualization import display_results
from components.molecule_view import display_molecule_details
from utils.api_client import compare_molecules, get_fingerprint_methods

def main():
    st.set_page_config(
        page_title="Molecular Similarity Analyzer",
        layout="wide",
        page_icon="🧪"
    )
    
    st.title("🧪 Molecular Similarity Analyzer")
    st.markdown("Compare molecular structures using multiple fingerprint methods")
    
    # Get available methods from backend
    methods_data = get_fingerprint_methods()
    available_methods = methods_data.get("available_methods", {})
    default_methods = methods_data.get("default_methods", ["morgan"])
    
    with st.sidebar:
        st.header("Input Parameters")
        master_file, target_files = file_uploader()
        methods = fingerprint_selector(available_methods, default_methods)
    
    if st.button("Calculate Similarity") and master_file and target_files and methods:
        with st.spinner("Calculating similarities..."):
            results = compare_molecules(master_file, target_files, methods)
            if results and not results.get("error"):
                display_results(results)
                
                # Show detailed view for selected molecule
                selected_target = st.selectbox(
                    "View detailed comparison for:",
                    options=list(results['results'].keys()))
                
                if selected_target:
                    display_molecule_details(
                        selected_target,
                        properties={
                            method: f"{results['results'][selected_target][method]:.3f}"
                            for method in methods
                        }
                    )
            else:
                st.error(f"Error: {results.get('error', 'Unknown error')}")

if __name__ == "__main__":
    main()