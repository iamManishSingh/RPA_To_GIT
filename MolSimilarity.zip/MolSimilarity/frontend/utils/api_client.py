import requests
from io import BytesIO
from typing import Union, List, Dict, Any

BASE_URL = "http://localhost:8000"

def compare_molecules(
    master: Union[BytesIO, str],
    targets: List[Union[BytesIO, str]],
    methods: List[str]
) -> Dict[str, Any]:
    """Send comparison request to backend"""
    try:
        # Handle image vs SMILES input
        if isinstance(master, BytesIO):
            master_smiles = convert_image_to_smiles(master)
        else:
            master_smiles = master.strip()
        
        target_smiles = []
        for target in targets:
            if isinstance(target, BytesIO):
                smiles = convert_image_to_smiles(target)
            else:
                smiles = target.strip()
            if smiles:
                target_smiles.append(smiles)
        
        payload = {
            "master_smiles": master_smiles,
            "target_smiles": target_smiles,
            "methods": methods,
            "metric": "tanimoto"
        }
        
        response = requests.post(
            f"{BASE_URL}/similarity/compare",
            json=payload
        )
        return response.json()
    except Exception as e:
        return {"error": str(e)}

def convert_image_to_smiles(image_file: BytesIO) -> str:
    """Convert image to SMILES via API"""
    try:
        files = {"file": image_file.getvalue()}
        response = requests.post(
            f"{BASE_URL}/conversion/image-to-smiles",
            files=files
        )
        data = response.json()
        return data["smiles"] if data["success"] else None
    except Exception:
        return None

def get_molecule_image(smiles: str, width: int = 300, height: int = 300) -> str:
    """Get molecule image from SMILES"""
    try:
        response = requests.get(
            f"{BASE_URL}/molecules/{smiles}/image",
            params={"width": width, "height": height}
        )
        return response.json()["image"]
    except Exception:
        return ""