from rdkit import Chem
from rdkit.Chem import Draw
from PIL import Image
from typing import List, Dict, Optional
import io

def get_fingerprint_type_params(fp_type: str) -> Dict:
    """Get default parameters for fingerprint types"""
    params = {
        "morgan": {"radius": 2, "n_bits": 2048},
        "rdkit": {"minPath": 1, "maxPath": 7},
        "maccs": {},  # MACCS has fixed params
        "atom_pair": {"n_bits": 2048}
    }
    return params.get(fp_type.lower(), {})

def draw_molecule_grid(smiles_list: List[str], 
                      mols_per_row: int = 4, 
                      size: tuple = (200, 200)) -> Optional[Image.Image]:
    """Generate a grid of molecule images"""
    mols = [Chem.MolFromSmiles(s) for s in smiles_list if Chem.MolFromSmiles(s)]
    if not mols:
        return None
        
    return Draw.MolsToGridImage(
        mols,
        molsPerRow=mols_per_row,
        subImgSize=size
    )

def smiles_to_image(smiles: str, size: tuple = (300, 300)) -> Optional[bytes]:
    """Convert SMILES to PNG bytes"""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        img = Draw.MolToImage(mol, size=size)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    return None