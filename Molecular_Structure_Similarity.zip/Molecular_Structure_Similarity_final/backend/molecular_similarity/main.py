from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from services import (
    conversion_service, 
    fingerprint_service, 
    similarity_service
)
from schemas.request_models import SimilarityRequest
from schemas.response_models import SimilarityResponse

app = FastAPI(title="Molecular Similarity API")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/convert/image-to-smiles")
async def convert_image_to_smiles(
    file: UploadFile = File(...),
    backend: str = "decimer"  # Only accepts "decimer" or "rdkit" now
):
    valid_backends = ["decimer", "rdkit"]
    if backend not in valid_backends:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid backend. Choose from {valid_backends}"
        )
    
    image_bytes = await file.read()
    try:
        smiles = conversion_service.image_to_smiles(image_bytes, backend)
        return {"smiles": smiles, "backend_used": backend}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/calculate/similarity")
async def calculate_similarity(request: SimilarityRequest):
    try:
        # Generate fingerprints
        ref_fp = fingerprint_service.generate_fingerprint(
            request.reference_smiles,
            request.fingerprint_type.lower()  # Ensure lowercase
        )
        if ref_fp is None:
            raise HTTPException(400, detail="Failed to generate reference fingerprint")
            
        target_fps = []
        for smi in request.target_smiles:
            fp = fingerprint_service.generate_fingerprint(
                smi,
                request.fingerprint_type.lower()
            )
            if fp is None:
                raise HTTPException(400, detail=f"Failed to generate fingerprint for: {smi}")
            target_fps.append(fp)
        
        # Calculate similarities
        similarities = similarity_service.calculate_similarity(
            ref_fp,
            target_fps,
            request.similarity_metric.lower()
        )
        
        return SimilarityResponse(
            reference_smiles=request.reference_smiles,
            target_smiles=request.target_smiles,
            similarities=similarities,
            fingerprint_type=request.fingerprint_type,
            similarity_metric=request.similarity_metric
        )
    except ValueError as e:
        raise HTTPException(400, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)