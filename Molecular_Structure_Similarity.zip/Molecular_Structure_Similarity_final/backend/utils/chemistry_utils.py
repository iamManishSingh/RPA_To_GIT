from rdkit import Chem
from rdkit.Chem import AllChem
from typing import Dict, Optional

def validate_smiles(smiles: str) -> bool:
    """Validate if a SMILES string is chemically valid"""
    return Chem.MolFromSmiles(smiles) is not None

def standardize_smiles(smiles: str) -> Optional[str]:
    """Convert SMILES to standardized form"""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        return Chem.MolToSmiles(mol, isomericSmiles=True)
    return None

def get_molecular_properties(smiles: str) -> Optional[Dict]:
    """Calculate basic molecular properties"""
    mol = Chem.MolFromSmiles(smiles)
    if not mol:
        return None
    
    return {
        "molecular_weight": AllChem.CalcExactMolWt(mol),
        "heavy_atoms": mol.GetNumHeavyAtoms(),
        "ring_count": mol.GetRingInfo().NumRings()
    }

def get_fingerprint_type_params(fp_type: str) -> Dict:
    """Get default parameters for fingerprint types"""
    params = {
        "morgan": {"radius": 2, "n_bits": 2048},
        "rdkit": {"minPath": 1, "maxPath": 7},
        "maccs": {},  # MACCS has fixed params
        "atom_pair": {"n_bits": 2048}
    }
    return params.get(fp_type.lower(), {})