from rdkit import Chem
from PIL import Image
import io
import numpy as np

class ConversionService:
    def __init__(self):
        self.decimer = None
    
    def _get_decimer(self):
        if self.decimer is None:
            from DECIMER import DECIMER
            self.decimer = DECIMER()
        return self.decimer
    
    def image_to_smiles(self, image_bytes: bytes, backend: str = "decimer"):
        try:
            img = Image.open(io.BytesIO(image_bytes))
            
            if backend == "decimer":
                smiles = self._get_decimer().predict(img)
                if self._validate_smiles(smiles):
                    return smiles
                raise ValueError("DECIMER returned invalid SMILES")
            elif backend == "rdkit":
                return self._rdkit_conversion(image_bytes)
            else:
                raise ValueError(f"Unsupported backend: {backend}")
        except Exception as e:
            raise ValueError(f"{backend} conversion failed: {str(e)}")
    
    def _validate_smiles(self, smiles: str) -> bool:
        return Chem.MolFromSmiles(smiles) is not None
    
    def _rdkit_conversion(self, image_bytes: bytes) -> str:
        try:
            import cv2
            nparr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            mol = Chem.MolFromImage(img)
            if mol:
                return Chem.MolToSmiles(mol)
            raise ValueError("RDKit couldn't parse the image")
        except Exception as e:
            raise ValueError(f"RDKit error: {str(e)}")

conversion_service = ConversionService()