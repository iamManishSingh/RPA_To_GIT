from rdkit import DataStructs
from typing import List

class SimilarityService:
    def calculate_similarity(
        self, 
        ref_fp, 
        target_fps: List, 
        metric: str = "tanimoto"
    ) -> List[float]:
        metric = metric.lower()
        if metric == "tanimoto":
            return [DataStructs.TanimotoSimilarity(ref_fp, fp) for fp in target_fps]
        elif metric == "dice":
            return [DataStructs.DiceSimilarity(ref_fp, fp) for fp in target_fps]
        elif metric == "cosine":
            return [self._cosine_similarity(ref_fp, fp) for fp in target_fps]
        else:
            raise ValueError(f"Unsupported metric: {metric}")
    
    def _cosine_similarity(self, fp1, fp2):
        # Implement cosine similarity for fingerprints
        from numpy import dot
        from numpy.linalg import norm
        arr1 = fp1.ToList()
        arr2 = fp2.ToList()
        return dot(arr1, arr2)/(norm(arr1)*norm(arr2))

# Singleton instance
similarity_service = SimilarityService()