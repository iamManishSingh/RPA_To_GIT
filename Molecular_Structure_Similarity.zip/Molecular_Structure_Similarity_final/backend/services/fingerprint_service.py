from rdkit import Chem
from rdkit.Chem import AllChem, AtomPairs
from typing import Union

class FingerprintService:
    @staticmethod
    def generate_fingerprint(
        smiles: str, 
        fp_type: str = "morgan",
        radius: int = 2,
        n_bits: int = 2048
    ) -> Union[bytes, None]:
        """Generate molecular fingerprint from SMILES"""
        mol = Chem.MolFromSmiles(smiles)
        if not mol:
            raise ValueError(f"Invalid SMILES: {smiles}")
            
        fp_type = fp_type.lower()
        try:
            if fp_type == "morgan":
                return AllChem.GetMorganFingerprintAsBitVect(mol, radius, nBits=n_bits)
            elif fp_type == "rdkit":
                return Chem.RDKFingerprint(mol)
            elif fp_type == "maccs":
                return Chem.MACCSkeys.GenMACCSKeys(mol)
            elif fp_type == "atom_pair":
                return AtomPairs.GetAtomPairFingerprintAsBitVect(mol)
            else:
                raise ValueError(f"Unsupported fingerprint type: {fp_type}")
        except Exception as e:
            raise ValueError(f"Fingerprint generation failed: {str(e)}")

# Create a module-level instance
fingerprint_service = FingerprintService()